##########################
Student Attendance System
##########################

Built using PHP, XAMPP, MySQL and the CodeIgniter framework.
