<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";
$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
    
} 
$id= $_POST["C_id"];
$count=0;
$res_emp =false;
$error_txt ="";
$sql1 = "SELECT * FROM attendance WHERE ClassID= $id";
$result = mysqli_query($con,$sql1);
	while ($row = $result->fetch_assoc()) {
   // echo $row['StudentID']."<br>";
	
		$count+=1;
}
if ($count == 0 ){
    $res_emp=true;
     $error_txt= "No records found for Class ID $id ";
 }
?>

<html>
    <body>
    <?php if($res_emp !== true) : ?>
        <h4>Total Students Attended for ClassID <?php echo $id ; ?> :<?php echo $count ?> </h4>
<?php endif; ?>
<h4> <?php echo $error_txt; ?> </h4>
</body>
</html>