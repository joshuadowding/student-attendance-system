<?php
//session_start();
$isIndex = 1;
// echo $_SESSION["currentUser"]->userType;
if($_SESSION["currentUser"]->userType=='Student') {
	header('Location: http://localhost:8081/student-attendance-system/index.php/students/');
   } 
   else {
	 if(!$isIndex) header('Location: http://localhost:8081/student-attendance-system/index.php/login/');
   }
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";

// if (isset($_POST['submit'])){
// 	$title = $_POST["name"];

// }
// echo $_SESSION['currentUser'].UserID;
$id= $_SESSION["UserID"];//$_POST["S_id"];
// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
    
} 
$error_txt="";
$res_emp = false;
// $count=0;
// $count1=0;
// $count2=0;
// $count3=0;
// $sql1 = "SELECT * FROM attendance WHERE ClassID=1";
// $result = mysqli_query($con,$sql1);
// 	while ($row = $result->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count+=1;
// 	}
	
// }

// $sql2 = "SELECT StudentID FROM attendance WHERE ClassID=2";
// $result1 = mysqli_query($con,$sql2);
// 	while ($row = $result1->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count1+=1;
// 	}
// }

// $sql3 = "SELECT StudentID FROM attendance WHERE ClassID=3";
// $result2 = mysqli_query($con,$sql3);
// 	while ($row = $result2->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count2+=1;
// 	}
// }

// $sql4 = "SELECT StudentID FROM attendance WHERE ClassID=4";
//     $result3 = mysqli_query($con,$sql4);
// 	while ($row = $result3->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count3+=1;
// 	}
// }


$sql1 = "SELECT m.Title,count(*) as count FROM `attendance` a inner join `modules.classes` c on a.ClassID=c.ClassID inner join `modules` m on m.ModuleID=c.ModuleID inner join `Staff` s on s.StaffID=c.StaffID where s.UserID=$id GROUP by m.ModuleID;";
$result1 = mysqli_query($con,$sql1);
//echo $result1->num_rows ,'</br>';
$count=0;
$count1=0;
$count2=0;
$count3=0;
if ($result1->num_rows==0){
		$res_emp=true;
	 	$error_txt= "No records found for Student ID $id ";
	 }
$dataPoints = array();
//$array = array();
while ($row = $result1->fetch_assoc()) {
	$data1 = array();
	$data1['label'] = $row['Title'];
	$data1['y'] = $row['count'];
	array_push($dataPoints,$data1);
}
//echo json_encode($dataPoints, JSON_NUMERIC_CHECK);
// 
?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Home - Student Attendance System</title>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/templatemo-style.css">

<style>
.canvasjs-chart-credit{
	display:none !important;
}

/*nav-bar-styles*/
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
<script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Attendance By Class " 
	},
	subtitles: [{
		text: "Specific Year"
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#,##0.00",
		indexLabel: "{label} {y}",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
		
	}]
	
});
chart.render();
 
}

</script>
</head>
<body>
<?php include("includes/body-preloader-contents.php"); ?>
    <?php include("includes/body-menu-contents.php"); ?>


<?php if($res_emp !== true) : ?>
    <div id="chartContainer" style="height: 370px; width: 100%;"></div>
<?php endif; ?>

<div>
<h4> <?php echo $error_txt; ?> </h4>
</div>

<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>                              