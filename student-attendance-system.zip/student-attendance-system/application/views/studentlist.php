<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php
//session_start();
$isIndex = 1;
// echo $_SESSION['UserID'];
if($_SESSION["currentUser"]->userType=='Student') {
 header('Location: http://localhost:8081/student-attendance-system/index.php/students/');
} 
else {
  if(!$isIndex) header('Location: http://localhost:8081/student-attendance-system/index.php/login/');
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";

// if (isset($_POST['submit'])){
// 	$title = $_POST["name"];

// }

$id= $_SESSION["UserID"];//$_POST["S_id"];
// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
    
} 
$error_txt="";
$res_emp = false;
// $count=0;
// $count1=0;
// $count2=0;
// $count3=0;
// $sql1 = "SELECT * FROM attendance WHERE ClassID=1";
// $result = mysqli_query($con,$sql1);
// 	while ($row = $result->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count+=1;
// 	}
	
// }

// $sql2 = "SELECT StudentID FROM attendance WHERE ClassID=2";
// $result1 = mysqli_query($con,$sql2);
// 	while ($row = $result1->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count1+=1;
// 	}
// }

// $sql3 = "SELECT StudentID FROM attendance WHERE ClassID=3";
// $result2 = mysqli_query($con,$sql3);
// 	while ($row = $result2->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count2+=1;
// 	}
// }

// $sql4 = "SELECT StudentID FROM attendance WHERE ClassID=4";
//     $result3 = mysqli_query($con,$sql4);
// 	while ($row = $result3->fetch_assoc()) {
//    // echo $row['StudentID']."<br>";
// 	if($row['StudentID'] == $id){
// 		$count3+=1;
// 	}
// }
// $db = db_connect();
$sql1 = "SELECT FirstName,LastName,UserID FROM `students`;";
//$sql1 = "SELECT concat(m.Title,'-',c.ClassType) as Title,count(*) as count FROM `attendance` a inner join `modules.classes` c on a.ClassID=c.ClassID inner join `modules` m on m.ModuleID=c.ModuleID where a.StudentID=1 GROUP by m.ModuleID,c.ClassType;";
$this->load->database();
$result1 = $this->db->query($sql1);
$row = $result1->result_array();
//echo $result1->num_rows ,'</br>';
$count=0;
$count1=0;
$count2=0;
$count3=0;
//echo $sql1;

// $dataPoints = array();
// //$array = array();
// while ($row = $result1->fetch_assoc()) {
// 	$data1 = array();
// 	$data1['label'] = $row['Title'];
// 	$data1['y'] = $row['count'];
// 	array_push($dataPoints,$data1);
// }
//echo json_encode($dataPoints, JSON_NUMERIC_CHECK);
// 
?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!--<title>Home - Student Attendance System</title>-->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/templatemo-style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">





<style>
.canvasjs-chart-credit{
	display:none !important;
}
/*---------------------------------------
      MENU
  -----------------------------------------*/

  .custom-navbar {
    border: none;
    margin-bottom: 0;
    padding: 25px 0;
    background-color: rgba(0, 0, 0, 0.75);
  }

  .custom-navbar .navbar-brand {
    color: #ffffff;
    font-size: 18px;
    font-weight: bold;
  }

  .custom-navbar .navbar-brand span {
    color: #ce3232;
  }

  .top-nav-collapse {
    background: #ffffff;
  }

  .custom-navbar .navbar-nav.navbar-nav-first {
    margin-left: 8em;
  }

  .custom-navbar .navbar-nav.navbar-right li a {
    padding-right: 12px;
    padding-left: 12px;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn {
    display: inline-block;
    margin: 0.2em 0 0 1em;
    background-color:aquamarine;
    padding:10px;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn:hover {
    background: #292929;
    color: #ffffff;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn:focus {
    color: #ffffff;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn a {
    padding: 10px 25px;
  }

  .custom-navbar .nav .section-btn a:hover {
    color: #ffffff;
  }

  .custom-navbar .nav li a {
    font-size: 12px;
    font-weight: bold;
    color: #ffffff;
    padding-right: 22px;
    padding-left: 22px;
    text-transform: uppercase;
  }

  .custom-navbar .nav li a:hover {
    background: transparent;
    color: #ce3232;
  }

  .custom-navbar .navbar-nav > li > a:hover,
  .custom-navbar .navbar-nav > li > a:focus {
    background-color: transparent;
  }

  .custom-navbar .nav li.active > a {
    background-color: transparent;
    color: #ce3232;
  }

  .custom-navbar .navbar-toggle {
    border: none;
    padding-top: 10px;
  }

  .custom-navbar .navbar-toggle {
    background-color: transparent;
  }

  .custom-navbar .navbar-toggle .icon-bar {
    background: #252525;
    border-color: transparent;
  }

  @media(min-width:768px) {
    .custom-navbar {
      border-bottom: 0;
      background-color: rgba(0, 0, 0, 0.75);
    }

    .custom-navbar.top-nav-collapse {
      background: #ffffff;
      -webkit-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
      -moz-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
      box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
      padding: 12px 0;
    }

    .top-nav-collapse .navbar-brand {
      color: #454545;
    }

    .top-nav-collapse .nav li a {
      color: #575757;
    }

    .top-nav-collapse .nav .section-btn a {
      color: #ffffff;
    }
  }

</style>
<script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Your Attendance by Class " 
	},
	subtitles: [{
		text: "Specific Year"
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#,##0.00",
		indexLabel: "{label} {y}",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
  <table>
	<?php include("includes/body-preloader-contents.php"); ?>
	<?php include("includes/body-menu-contents.php"); ?>

<br>
<br>
<br>
<br>
<br>

<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<?php
// $row = $result1->fetch_assoc();
// echo print_r($row);

  foreach ($row as $r) {
    echo '<tr>';
  echo '<td>','<a href="http://localhost:8081/student-attendance-system/index.php/teacherstudent/?id=',$r['UserID'],' ">',$r['FirstName'],' ',$r['LastName'],'</a>', '</td>','<td>',$result1->num_rows,'</td>';
  // mysqli_free_result($result1);
  echo '</tr>';
}
?>
</table>
</body>
</html>                              