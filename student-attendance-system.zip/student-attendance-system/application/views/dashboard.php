<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Home - Student Attendance System</title>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/templatemo-style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<style>

.dashboard-design{
    padding:50px;
    padding-bottom:200px;
    background-color: #d0cef5;
}

/*---------------------------------------
      MENU
  -----------------------------------------*/

  .custom-navbar {
    border: none;
    margin-bottom: 0;
    padding: 25px 0;
    background-color: rgba(0, 0, 0, 0.75);
  }

  .custom-navbar .navbar-brand {
    color: #ffffff;
    font-size: 18px;
    font-weight: bold;
  }

  .custom-navbar .navbar-brand span {
    color: #ce3232;
  }

  .top-nav-collapse {
    background: #ffffff;
  }

  .custom-navbar .navbar-nav.navbar-nav-first {
    margin-left: 8em;
  }

  .custom-navbar .navbar-nav.navbar-right li a {
    padding-right: 12px;
    padding-left: 12px;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn {
    display: inline-block;
    margin: 0.2em 0 0 1em;
    background-color:aquamarine;
    padding:10px;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn:hover {
    background: #292929;
    color: #ffffff;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn:focus {
    color: #ffffff;
  }

  .custom-navbar .navbar-nav.navbar-right .section-btn a {
    padding: 10px 25px;
  }

  .custom-navbar .nav .section-btn a:hover {
    color: #ffffff;
  }

  .custom-navbar .nav li a {
    font-size: 12px;
    font-weight: bold;
    color: #ffffff;
    padding-right: 22px;
    padding-left: 22px;
    text-transform: uppercase;
  }

  .custom-navbar .nav li a:hover {
    background: transparent;
    color: #ce3232;
  }

  .custom-navbar .navbar-nav > li > a:hover,
  .custom-navbar .navbar-nav > li > a:focus {
    background-color: transparent;
  }

  .custom-navbar .nav li.active > a {
    background-color: transparent;
    color: #ce3232;
  }

  .custom-navbar .navbar-toggle {
    border: none;
    padding-top: 10px;
  }

  .custom-navbar .navbar-toggle {
    background-color: transparent;
  }

  .custom-navbar .navbar-toggle .icon-bar {
    background: #252525;
    border-color: transparent;
  }

  @media(min-width:768px) {
    .custom-navbar {
      border-bottom: 0;
      background-color: rgba(0, 0, 0, 0.75);
    }

    .custom-navbar.top-nav-collapse {
      background: #ffffff;
      -webkit-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
      -moz-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
      box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
      padding: 12px 0;
    }

    .top-nav-collapse .navbar-brand {
      color: #454545;
    }

    .top-nav-collapse .nav li a {
      color: #575757;
    }

    .top-nav-collapse .nav .section-btn a {
      color: #ffffff;
    }
  }

</style>
</head>

<body>
    <?php include("includes/body-preloader-contents.php"); ?>
    <?php include("includes/body-menu-contents.php"); ?>
    <br>
    <br>
    <br>
    <br>
<a href="http://localhost:8081/student-attendance-system/index.php/login/" class="btn-primary"></a><h1><center><b>Welcome To Attendance System</b></center></h1>

<br>
<br>
<br>
    <div class="container dashboard-design">
        <div class="row">
            <div class="col-sm-4">
            <a href="http://localhost:8081/student-attendance-system/index.php/studentlist/" class="icon-block">
                <i class='fas fa-portrait' style='font-size:130px;color:black'></i>
            </a>
            
            </div>
            
            <div class="col-sm-4">
            <a href="http://localhost:8081/student-attendance-system/index.php/teacher/" class="icon-block">
                <i class='fas fa-portrait' style='font-size:130px;color:black'></i>
            </a>
            </div>
            <div class="col-sm-4">
            <a href="http://localhost:8081/student-attendance-system/index.php/teacher/module/" class="icon-block">
                <i class='fas fa-portrait' style='font-size:130px;color:black'></i>
            </a>

            </div>
           
            <div class="col-sm-4">
                <br>
            <button type="button" class="btn btn-primary">Student Attendance</button>
            </div>
            <div class="col-sm-4">
                <br>
            <button type="button" class="btn btn-primary">Attendance by class</button>
            </div>
            <div class="col-sm-4">
                <br>
            <button type="button" class="btn btn-primary">Attendance by module</button>
            </div>

            
        </div>
    </div>


    

    <!-- HOME -->
    <section id="home" class="slider" data-stellar-background-ratio="0.5">
        <div class="row">

            
</body>

</html>