<section class="preloader">
    <div class="spinner">
        <span class="spinner-rotate"></span>
    </div>
</section>