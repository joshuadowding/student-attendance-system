<footer id="footer" data-stellar-background-ratio="0.5">
    <div class="container">
        <div class="row">

            <div class="col-md-3 col-sm-8">
                <div class="footer-info">
                    <div class="section-title">
                        <h2 class="wow fadeInUp" data-wow-delay="0.2s">Find us</h2>
                    </div>
                    <address class="wow fadeInUp" data-wow-delay="0.4s">
                        <p>123 nulla a cursus rhoncus,<br> augue sem viverra 10870<br>id ultricies sapien</p>
                    </address>
                </div>
            </div>

            <div class="col-md-3 col-sm-8">
                <div class="footer-info">
                    <div class="section-title">
                        <h2 class="wow fadeInUp" data-wow-delay="0.2s">sign up</h2>
                    </div>
                    <address class="wow fadeInUp" data-wow-delay="0.4s">
                        <p>090-080-0650 | 090-070-0430</p>
                        <p><a href="mailto:info@company.com">info@company.com</a></p>
                        <p>LINE: eatery247 </p>
                    </address>
                </div>
            </div>

            <div class="col-md-4 col-sm-8">
                <div class="footer-info footer-open-hour">
                    <div class="section-title">
                        <h2 class="wow fadeInUp" data-wow-delay="0.2s">view system</h2>
                    </div>
                </div>
            </div>

            <div class="col-md-2 col-sm-4">
                <ul class="wow fadeInUp social-icon" data-wow-delay="0.4s">
                    <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                    <li><a href="#" class="fa fa-twitter"></a></li>
                    <li><a href="#" class="fa fa-instagram"></a></li>
                    <li><a href="#" class="fa fa-google"></a></li>
                </ul>

                <div class="wow fadeInUp copyright-text" data-wow-delay="0.8s">
                    <p><br>Copyright &copy; 2020 <br>Student Attendance System

                        <br><br>Design: TemplateMo</p>
                </div>
            </div>

        </div>
    </div>
</footer>