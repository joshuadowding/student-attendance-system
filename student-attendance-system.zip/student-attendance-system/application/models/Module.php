<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    // db->modules
    class Module {
        public $moduleID;
        public $staffID;
        public $title;
        public $dateCreated;
        public $lastEdited;

        public $lessons;
    }
?>
