<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    // db->users
    class User {
        public $userFirstName;
        public $userLastName;
        public $userEmail;
        public $userID;
        public $userType;
    }
?>