<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    // db->attendance
    class Attendance {
        public $attendanceID;
        public $classID;
        public $studentID;
        public $attended;
        public $late;
        public $week;
    }
?>
