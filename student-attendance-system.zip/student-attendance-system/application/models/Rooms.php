<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    // db->rooms
    class Rooms {
    	public $RoomID;
    	public $Name;
    	public $Location;
    	public $Capacity;
    }
?>