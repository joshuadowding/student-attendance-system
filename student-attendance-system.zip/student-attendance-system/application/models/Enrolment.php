<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    // db->modules.students
    class Enrolment {
        public $moduleID;
        public $studentID;
        public $startDate;
        public $endDate;
    }
?>
